(c) SanyaBane

English install instruction:
https://www.dropbox.com/s/4qtivwzx9laopt5/Readme_ENG.docx?dl=0

Инструкция по установке на русском:
https://www.dropbox.com/s/gmtgftic6feckn9/Readme_RUS.docx?dl=0


=============================
My VK.com group:
http://vk.com/dota2_sanyabane
=============================
My Youtube channel:
https://www.youtube.com/channel/UC4KPAXA6Vz8rgtgFocemVSg
=============================
My Steam group:
http://steamcommunity.com/groups/dota2_sanyabane
=============================