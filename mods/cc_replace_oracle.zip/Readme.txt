﻿Shiroya Gespenst

Sanyabane's English install instruction:
https://www.dropbox.com/s/4qtivwzx9laopt5/Readme_ENG.docx?dl=0

mod安装教程：
http://www.dota2rpg.com/forum.php?mod=viewthread&tid=2959&extra=page%3D1
http://www.dota2rpg.com/forum.php?mod=viewthread&tid=3260&extra=page%3D1

Sanyabane's VPK Creator and Remove_Cosmetics 
Sanyabane 的vpk打包工具和残留饰品移除工具
https://vk.com/page-88134082_51573588

我做的steam二次元自定义游戏 moetomoe：
My Steam anime custom game moetomoe:
https://steamcommunity.com/sharedfiles/filedetails/?id=805893808

禁止商业利用
